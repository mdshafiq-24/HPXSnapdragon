"""AI-Powered Memory Compression: core (capture -> embed -> compress -> query)."""
import os, time, uuid, zlib
from pathlib import Path
import numpy as np
from sklearn.cluster import AgglomerativeClustering

try:
    import faiss
except ImportError:          # e.g. no ARM64 wheel: fall back to numpy search
    faiss = None

DIM = 384
_embedder = None


# ---------- embeddings ----------
def _load_embedder():
    """EMBEDDER=hash (tests) | ONNX_MODEL_DIR=<dir> (NPU via QNN) | SentenceTransformer."""
    if os.getenv("EMBEDDER") == "hash":
        return ("hash", None)
    model_dir = os.getenv("ONNX_MODEL_DIR")
    if model_dir:
        import onnxruntime as ort
        from tokenizers import Tokenizer
        avail = ort.get_available_providers()
        prov = [p for p in ("QNNExecutionProvider", "CPUExecutionProvider") if p in avail]
        sess = ort.InferenceSession(str(Path(model_dir) / "model.onnx"), providers=prov)
        tok = Tokenizer.from_file(str(Path(model_dir) / "tokenizer.json"))
        tok.enable_padding(length=128)       # static shape suits the NPU
        tok.enable_truncation(128)
        return ("onnx", (sess, tok))
    from sentence_transformers import SentenceTransformer
    return ("st", SentenceTransformer("all-MiniLM-L6-v2"))


def generate_embedding(text: str) -> np.ndarray:
    """Return a unit-length float32 vector (so dot product == cosine similarity)."""
    global _embedder
    _embedder = _embedder or _load_embedder()
    kind, m = _embedder
    if kind == "hash":
        v = np.zeros(DIM, "float32")
        for w in text.lower().split():
            v[zlib.crc32(w.encode()) % DIM] += 1
    elif kind == "onnx":
        sess, tok = m
        enc = tok.encode(text)
        feeds = {"input_ids": np.array([enc.ids], "int64"),
                 "attention_mask": np.array([enc.attention_mask], "int64")}
        if "token_type_ids" in {i.name for i in sess.get_inputs()}:
            feeds["token_type_ids"] = np.zeros_like(feeds["input_ids"])
        h = sess.run(None, feeds)[0][0]                       # (tokens, DIM)
        mask = np.array(enc.attention_mask, "float32")[:, None]
        v = (h * mask).sum(0) / max(mask.sum(), 1)            # mean pooling
    else:
        v = m.encode(text)
    v = np.asarray(v, "float32")
    return v / (np.linalg.norm(v) or 1.0)


# ---------- store ----------
class MemoryStore:
    def __init__(self):
        self.nodes = {}          # id -> {text, source, ts, vec, count, merged}
        self._index, self._ids = None, []

    def invalidate(self):
        self._index = None

    def index(self):
        if self._index is None:
            self._ids = list(self.nodes)
            mat = np.stack([self.nodes[i]["vec"] for i in self._ids]).astype("float32")
            if faiss:
                self._index = faiss.IndexFlatIP(mat.shape[1])
                self._index.add(mat)
            else:
                self._index = mat
        return self._index, self._ids


def capture_activity(store: MemoryStore, text: str, source: str = "note") -> str:
    """Embed one activity and add it to memory. Returns its id."""
    nid = uuid.uuid4().hex[:8]
    store.nodes[nid] = dict(text=text, source=source, ts=time.time(),
                            vec=generate_embedding(text), count=1, merged=[])
    store.invalidate()
    return nid


def compress_memory(store: MemoryStore, threshold: float = 0.3) -> dict:
    """Cluster similar activities (cosine distance < threshold); keep one node per cluster."""
    before = len(store.nodes)
    if before < 2:
        return {"before": before, "after": before}
    ids = list(store.nodes)
    mat = np.stack([store.nodes[i]["vec"] for i in ids])
    labels = AgglomerativeClustering(n_clusters=None, distance_threshold=threshold,
                                     metric="cosine", linkage="average").fit_predict(mat)
    kept = {}
    for lab in set(labels):
        members = [ids[i] for i in np.flatnonzero(labels == lab)]
        centroid = mat[labels == lab].mean(0)
        rep = max(members, key=lambda m: float(store.nodes[m]["vec"] @ centroid))
        node = store.nodes[rep]
        for m in members:
            if m != rep:
                node["count"] += store.nodes[m]["count"]
                node["merged"] += [store.nodes[m]["text"]] + store.nodes[m]["merged"]
        node["merged"] = node["merged"][:20]
        kept[rep] = node
    store.nodes = kept
    store.invalidate()
    return {"before": before, "after": len(kept)}


def query_memory(store: MemoryStore, query: str, k: int = 3) -> list:
    """Return the k most cosine-similar nodes."""
    if not store.nodes:
        return []
    qv = generate_embedding(query)
    idx, ids = store.index()
    k = min(k, len(ids))
    if faiss:
        s, j = idx.search(qv[None], k)
        hits = zip(j[0], s[0])
    else:
        sims = idx @ qv
        order = np.argsort(-sims)[:k]
        hits = zip(order, sims[order])
    return [dict(id=ids[i], score=round(float(sc), 3),
                 **{f: store.nodes[ids[i]][f] for f in ("text", "source", "count", "merged")})
            for i, sc in hits]


if __name__ == "__main__":
    s = MemoryStore()
    for t in ["Met Priya to plan the Q3 budget", "Q3 budget planning meeting with Priya",
              "Budget planning for Q3 with Priya", "Cooked pasta for dinner",
              "Fixed login bug in the payments service", "Debugged payments service login bug"]:
        capture_activity(s, t)
    print("compress:", compress_memory(s))
    for h in query_memory(s, "what did I do about the budget?", k=2):
        print(h["score"], h["text"], f"(+{h['count']-1} merged)")
