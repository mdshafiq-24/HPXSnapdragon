import os
os.environ["EMBEDDER"] = "hash"          # no model download needed for tests
import memory_core as mc

DUPES = ["Met Priya to plan the Q3 budget", "Q3 budget plan, met Priya to plan", "Plan the Q3 budget met Priya"]

def make():
    s = mc.MemoryStore()
    for t in DUPES + ["Cooked pasta for dinner", "Fixed login bug in payments service"]:
        mc.capture_activity(s, t)
    return s

def test_capture():
    s = make(); assert len(s.nodes) == 5

def test_embedding_is_unit_length():
    assert abs(float((v := mc.generate_embedding("hello world")) @ v) - 1) < 1e-5

def test_compress_merges_similar_only():
    s = make(); r = mc.compress_memory(s)
    assert r == {"before": 5, "after": 3}
    assert max(n["count"] for n in s.nodes.values()) == 3

def test_query_finds_relevant():
    s = make(); mc.compress_memory(s)
    assert "budget" in mc.query_memory(s, "budget with Priya", k=1)[0]["text"].lower()

def test_empty_and_single():
    s = mc.MemoryStore(); assert mc.query_memory(s, "x") == []
    mc.capture_activity(s, "one"); assert mc.compress_memory(s)["after"] == 1

def test_scale():
    s = mc.MemoryStore()
    for i in range(600): mc.capture_activity(s, f"task{i % 20} step{i % 7} notes")
    r = mc.compress_memory(s, 0.3); assert r["after"] < 600
    assert mc.query_memory(s, "task3 step3", k=5)
