# AI-Powered Memory Compression (Snapdragon AI PC prototype)

    pip install -r requirements.txt
    python memory_core.py     # console demo
    pytest -q                 # tests (hash embedder, no download)
    python app.py             # UI at http://127.0.0.1:8000

## NPU path
Export MiniLM to ONNX (static shape 1x128, ideally quantized), then:

    set ONNX_MODEL_DIR=C:\models\minilm-onnx   (contains model.onnx + tokenizer.json)
    python app.py

`onnxruntime` picks QNNExecutionProvider when available, else CPU.
Without ONNX_MODEL_DIR the app uses SentenceTransformer (CPU).

## Notes
- Memory is in-process only (resets on restart); add persistence before real use.
- Compression is O(n^2); run it on batches (e.g. nightly or every ~2k activities).
