"""Local FastAPI app. Run: python app.py  ->  http://127.0.0.1:8000"""
from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import FileResponse
from pydantic import BaseModel
import memory_core as mc

app = FastAPI(title="Memory Compression")
store = mc.MemoryStore()


class Activity(BaseModel):
    text: str
    source: str = "note"


@app.post("/api/activity")
def add(a: Activity):
    return {"id": mc.capture_activity(store, a.text, a.source), "total": len(store.nodes)}


@app.post("/api/compress")
def compress(threshold: float = 0.3):
    return mc.compress_memory(store, threshold)


@app.get("/api/query")
def query(q: str, k: int = 3):
    return mc.query_memory(store, q, k)


@app.get("/api/stats")
def stats():
    return {"nodes": len(store.nodes), "activities": sum(n["count"] for n in store.nodes.values())}


@app.get("/")
def home():
    return FileResponse(Path(__file__).parent / "static" / "index.html")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
